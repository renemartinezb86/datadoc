**CHANGE CORS SETTINGS**
<br />
`gsutil cors set dev-cors.json gs://dataparse_local_test`

---
**RUN CHROME**
<br />
`google-chrome-stable --user-data-dir="/tmp/chrome-dev" --disable-web-security`

