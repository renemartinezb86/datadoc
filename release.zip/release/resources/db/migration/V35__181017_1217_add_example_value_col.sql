ALTER TABLE column_info ADD COLUMN example_value VARCHAR(255);

