ALTER TABLE "datadoc"
 ADD COLUMN committed timestamp without time zone;