alter table export_entity add column send_to VARCHAR(255);
alter table export_entity add column email_sent BOOLEAN;
alter table export_entity add column downloaded BOOLEAN;
