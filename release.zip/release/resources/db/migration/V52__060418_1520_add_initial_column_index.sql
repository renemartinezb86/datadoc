alter table column_info add column initial_index INTEGER;
