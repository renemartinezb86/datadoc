alter table db_descriptor add column disconnected_time TIMESTAMP;
