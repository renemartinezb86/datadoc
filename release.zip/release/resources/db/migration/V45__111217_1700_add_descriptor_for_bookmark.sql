alter table file_descriptor add column buffer_path TEXT;
alter table file_descriptor add column checksum TEXT;
