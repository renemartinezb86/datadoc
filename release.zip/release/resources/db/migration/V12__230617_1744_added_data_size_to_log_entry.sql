alter table bookmark_action_log
  add column size bigint;