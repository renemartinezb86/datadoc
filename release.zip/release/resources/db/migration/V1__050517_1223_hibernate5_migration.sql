alter  table abstract_file_entity_operation rename abstract_file to abstract_file_id;
alter  table abstract_file_entity_operation rename entity_operation to entity_operation_id;

alter  table table_schema_entity_operation rename table_schema to table_schema_id;
alter  table table_schema_entity_operation rename entity_operation to entity_operation_id;