ALTER table "user" add column avatar_path VARCHAR(255);
ALTER table "user" add column full_name VARCHAR(255);